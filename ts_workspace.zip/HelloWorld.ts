console.log("Hello world");

//import { TestDecorator } from './decorator/ClassDecorator';

//TestDecorator()